//
//  MyQRVC.h
//  ScanningView
//
//  Created by Mac on 2017/3/30.
//  Copyright © 2017年 yunniu. All rights reserved.
//

#import "ScanQRViewController.h"

@interface MyQRVC : ScanQRViewController

@end
